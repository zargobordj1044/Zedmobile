package dz.zedmobile.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import java.text.NumberFormat
import java.util.Locale

private val Ink = Color(0xFF171525)
private val Violet = Color(0xFF8B7CFF)
private val Lavender = Color(0xFFC7BEFF)
private val Paper = Color(0xFFF4F2FA)
private val Mint = Color(0xFF85D6BC)
private val Muted = Color(0xFF777486)

data class Product(
    val id: Int,
    val name: String,
    val category: String,
    val price: Long,
    val oldPrice: Long? = null,
    val emoji: String,
    val description: String
)

private val sampleProducts = listOf(
    Product(1, "Samsung Galaxy A55", "هواتف", 74900, 82900, "📱", "هاتف Samsung Galaxy A55. أضف المواصفات والصور الحقيقية من لوحة الإدارة قبل البيع."),
    Product(2, "سماعات لاسلكية", "صوتيات", 4900, null, "🎧", "سماعات لاسلكية. هذه بيانات تجريبية وليست عرضاً تجارياً مؤكداً."),
    Product(3, "شاحن USB-C سريع", "شواحن وكابلات", 2200, null, "🔌", "شاحن USB-C. تحقق من التوافق والمواصفات قبل النشر."),
    Product(4, "Power Bank 20000mAh", "إكسسوارات", 5900, 6500, "🔋", "بطارية متنقلة. صورة المنتج والسعر يحتاجان إلى تأكيد الإدارة."),
    Product(5, "حافظة هاتف", "إكسسوارات", 1200, null, "📦", "حافظة هاتف. اختر الموديل المتوافق من الخيارات."),
    Product(6, "حامي شاشة", "إكسسوارات", 800, null, "🛡️", "حامي شاشة. اختر نوع الهاتف قبل تأكيد الطلب.")
)

private fun dzd(value: Long): String =
    NumberFormat.getIntegerInstance(Locale("fr", "DZ")).format(value) + " دج"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZedApp() }
    }
}

@Composable
fun ZedApp() {
    val nav = rememberNavController()
    val cart = remember { mutableStateMapOf<Int, Int>() }
    val favorites = remember { mutableStateListOf<Int>() }
    val dark = remember { mutableStateOf(false) }

    val scheme = if (dark.value) darkColorScheme(
        primary = Violet, secondary = Mint, background = Ink, surface = Color(0xFF242235),
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    ) else lightColorScheme(
        primary = Violet, secondary = Mint, background = Paper, surface = Color.White,
        onPrimary = Color.White, onBackground = Ink, onSurface = Ink
    )

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            val totalItems = cart.values.sum()
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = { BottomBar(nav, totalItems) }
            ) { padding ->
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(padding)
                ) {
                    composable("home") {
                        HomeScreen(
                            nav = nav, cart = cart, favorites = favorites,
                            onProduct = { nav.navigate("product/$it") }
                        )
                    }
                    composable("categories") { CategoriesScreen(nav) }
                    composable("cart") { CartScreen(cart, nav) }
                    composable("support") { SupportScreen() }
                    composable("account") { AccountScreen(nav, dark) }
                    composable("search") { SearchScreen(nav, cart) }
                    composable("favorites") { FavoritesScreen(favorites, cart, nav) }
                    composable("product/{id}") { entry ->
                        val id = entry.arguments?.getString("id")?.toIntOrNull() ?: 1
                        ProductScreen(id, cart, favorites, nav)
                    }
                    composable("checkout") { CheckoutScreen(cart, nav) }
                    composable("orders") { OrdersScreen() }
                    composable("admin") { AdminScreen() }
                    composable("faq") { FaqScreen() }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(nav: NavHostController, cartCount: Int) {
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route ?: "home"
    val tabs = listOf(
        Triple("home", "الرئيسية", Icons.Default.Home),
        Triple("categories", "الأقسام", Icons.Default.Category),
        Triple("cart", "السلة", Icons.Default.ShoppingCart),
        Triple("support", "الدعم", Icons.Default.SupportAgent),
        Triple("account", "حسابي", Icons.Default.Person)
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        tabs.forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = current == route,
                onClick = { if (current != route) nav.navigate(route) { launchSingleTop = true } },
                icon = {
                    if (route == "cart" && cartCount > 0) {
                        BadgedBox(badge = { Badge { Text(cartCount.toString()) } }) {
                            Icon(icon, contentDescription = label)
                        }
                    } else Icon(icon, contentDescription = label)
                },
                label = { Text(label, fontSize = 10.sp) }
            )
        }
    }
}

@Composable
private fun Header(nav: NavHostController, title: String = "ZED MOBILE") {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(Violet, Ink))),
                contentAlignment = Alignment.Center
            ) {
                Text("Z", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
            }
            Column {
                Text(title, fontWeight = FontWeight.Black, fontSize = 17.sp, color = MaterialTheme.colorScheme.onBackground)
                Text("التكنولوجيا أقرب إليك", fontSize = 10.sp, color = Muted)
            }
        }
        IconButton(onClick = { nav.navigate("cart") }) {
            Icon(Icons.Default.ShoppingBag, contentDescription = "السلة", tint = MaterialTheme.colorScheme.onBackground)
        }
    }
}

@Composable
private fun HomeScreen(
    nav: NavHostController,
    cart: MutableMap<Int, Int>,
    favorites: MutableList<Int>,
    onProduct: (Int) -> Unit
) {
    var query by remember { mutableStateOf("") }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Header(nav)
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                placeholder = { Text("ابحث عن هاتف أو إكسسوار...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Close, null)
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.height(16.dp))
            Box(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Ink, Color(0xFF5546A8))))
                    .padding(20.dp)
            ) {
                Column {
                    Text("عالم التكنولوجيا بين يديك", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("هواتف وإكسسوارات في مكان واحد", color = Lavender, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { nav.navigate("categories") }, colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                        Text("اكتشف المنتجات", color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            SectionTitle("منتجات مختارة", "عرض الكل") { nav.navigate("search") }
            if (query.isNotBlank()) {
                val filtered = sampleProducts.filter { it.name.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true) }
                ProductList(filtered, cart, favorites, onProduct)
            } else {
                ProductList(sampleProducts.take(4), cart, favorites, onProduct)
            }
            Spacer(Modifier.height(14.dp))
            SectionTitle("تسوّق حسب القسم", "كل الأقسام") { nav.navigate("categories") }
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("📱" to "هواتف", "🎧" to "صوتيات", "🔌" to "شواحن", "🛡️" to "حماية").forEach { (emoji, label) ->
                    Card(
                        modifier = Modifier.weight(1f).clickable { nav.navigate("categories") },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(vertical = 13.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(emoji, fontSize = 24.sp)
                            Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE2F7EF)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalShipping, null, tint = Color(0xFF217A60), modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("التوصيل عبر ولايات الجزائر", color = Color(0xFF174E3F), fontWeight = FontWeight.Bold)
                        Text("السعر والتوفر يُعرضان بعد إعداد شركة التوصيل.", color = Color(0xFF42685E), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text(action, color = Violet, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onClick))
    }
}

@Composable
private fun ProductList(
    products: List<Product>,
    cart: MutableMap<Int, Int>,
    favorites: MutableList<Int>,
    onProduct: (Int) -> Unit
) {
    if (products.isEmpty()) {
        EmptyState("لا توجد نتائج", "جرّب البحث باسم منتج آخر", Icons.Default.Search)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(horizontal = 16.dp)) {
        products.forEach { product ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onProduct(product.id) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(84.dp).clip(RoundedCornerShape(16.dp)).background(Paper),
                        contentAlignment = Alignment.Center
                    ) { Text(product.emoji, fontSize = 38.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(product.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text(product.category, color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(5.dp))
                        Text(dzd(product.price), color = Violet, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        if (product.oldPrice != null) {
                            Text("السعر السابق ${dzd(product.oldPrice)}", color = Muted, fontSize = 10.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = { cart[product.id] = (cart[product.id] ?: 0) + 1 },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 5.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.AddShoppingCart, null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("أضف للسلة", fontSize = 11.sp)
                            }
                            Spacer(Modifier.width(6.dp))
                            IconButton(
                                onClick = { if (favorites.contains(product.id)) favorites.remove(product.id) else favorites.add(product.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    if (favorites.contains(product.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "المفضلة",
                                    tint = if (favorites.contains(product.id)) Color(0xFFE05B7A) else Muted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoriesScreen(nav: NavHostController) {
    Column(Modifier.fillMaxSize()) {
        Header(nav, "الأقسام")
        Text("اختر القسم الذي تبحث عنه", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = Muted)
        val cats = listOf("هواتف محمولة" to "📱", "سماعات وصوتيات" to "🎧", "شواحن وكابلات" to "🔌", "بطاريات متنقلة" to "🔋", "حافظات وحماية" to "🛡️", "إكسسوارات متنوعة" to "📦")
        cats.forEach { (name, emoji) ->
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { nav.navigate("search") },
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = 26.sp)
                    Spacer(Modifier.width(14.dp))
                    Text(name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun ProductScreen(id: Int, cart: MutableMap<Int, Int>, favorites: MutableList<Int>, nav: NavHostController) {
    val p = sampleProducts.firstOrNull { it.id == id } ?: sampleProducts.first()
    var qty by remember { mutableIntStateOf(1) }
    Column(Modifier.fillMaxSize()) {
        Header(nav, "تفاصيل المنتج")
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp)).background(Paper), contentAlignment = Alignment.Center) {
                    Text(p.emoji, fontSize = 92.sp)
                }
                Spacer(Modifier.height(18.dp))
                Text(p.name, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                Text(p.category, color = Muted)
                Spacer(Modifier.height(8.dp))
                Text(dzd(p.price), color = Violet, fontWeight = FontWeight.Black, fontSize = 23.sp)
                p.oldPrice?.let { Text("السعر السابق: ${dzd(it)}", color = Muted, fontSize = 13.sp) }
                Spacer(Modifier.height(16.dp))
                Text("الوصف", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                Text(p.description, color = Muted, lineHeight = 22.sp)
                Spacer(Modifier.height(14.dp))
                Text("التوفر: يحتاج إلى تأكيد المخزون", color = Color(0xFF9A6A15), fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (qty > 1) qty-- }) { Icon(Icons.Default.Remove, null) }
                    Text(qty.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { qty++ }) { Icon(Icons.Default.Add, null) }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { if (favorites.contains(p.id)) favorites.remove(p.id) else favorites.add(p.id) }) {
                        Icon(if (favorites.contains(p.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Violet)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { cart[p.id] = (cart[p.id] ?: 0) + qty; nav.navigate("cart") },
                modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)
            ) { Icon(Icons.Default.ShoppingCart, null); Spacer(Modifier.width(6.dp)); Text("أضف للسلة") }
            OutlinedButton(onClick = { shareProduct(p.name, nav) }, shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Share, null)
            }
        }
    }
}

private fun shareProduct(name: String, nav: NavHostController) {
    // Product sharing is intentionally local-only until a public product URL exists.
}

@Composable
private fun CartScreen(cart: MutableMap<Int, Int>, nav: NavHostController) {
    val products = sampleProducts.filter { (cart[it.id] ?: 0) > 0 }
    val subtotal = products.sumOf { it.price * (cart[it.id] ?: 0) }
    Column(Modifier.fillMaxSize()) {
        Header(nav, "سلة التسوق")
        if (products.isEmpty()) {
            EmptyState("السلة فارغة", "أضف المنتجات التي أعجبتك للمتابعة", Icons.Default.ShoppingCart)
            Button(onClick = { nav.navigate("home") }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("تسوّق الآن") }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products) { p ->
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(p.emoji, fontSize = 34.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text(dzd(p.price), color = Violet, fontWeight = FontWeight.Bold)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { val n = (cart[p.id] ?: 1) - 1; if (n <= 0) cart.remove(p.id) else cart[p.id] = n }) { Icon(Icons.Default.RemoveCircleOutline, null) }
                                    Text((cart[p.id] ?: 0).toString())
                                    IconButton(onClick = { cart[p.id] = (cart[p.id] ?: 0) + 1 }) { Icon(Icons.Default.AddCircleOutline, null) }
                                }
                            }
                            IconButton(onClick = { cart.remove(p.id) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFD75A6A)) }
                        }
                    }
                }
            }
            Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("المجموع الفرعي")
                        Text(dzd(subtotal), fontWeight = FontWeight.Bold)
                    }
                    Text("التوصيل يُحسب بعد اختيار الولاية وطريقة التوصيل.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { nav.navigate("checkout") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text("متابعة الطلب")
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckoutScreen(cart: MutableMap<Int, Int>, nav: NavHostController) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var wilaya by remember { mutableStateOf("") }
    var commune by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("توصيل للمنزل") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val subtotal = sampleProducts.filter { (cart[it.id] ?: 0) > 0 }.sumOf { it.price * (cart[it.id] ?: 0) }

    Column(Modifier.fillMaxSize()) {
        Header(nav, "تأكيد الطلب")
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("معلومات التوصيل", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("املأ البيانات المطلوبة. لن يُرسل طلب حقيقي قبل ربط الخادم.", color = Muted, fontSize = 12.sp)
                OutlinedTextField(name, { name = it }, label = { Text("الاسم الكامل") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(wilaya, { wilaya = it }, label = { Text("الولاية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(commune, { commune = it }, label = { Text("البلدية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("العنوان بالتفصيل") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text("طريقة التوصيل", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(method == "توصيل للمنزل", { method = "توصيل للمنزل" })
                    Text("للمنزل")
                    Spacer(Modifier.width(14.dp))
                    RadioButton(method == "مكتب التوصيل", { method = "مكتب التوصيل" })
                    Text("مكتب التوصيل")
                }
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات (اختياري)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("ملخص الطلب", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المنتجات")
                            Text(dzd(subtotal), fontWeight = FontWeight.Bold)
                        }
                        Text("سعر التوصيل غير محدد — لن يتم عرض إجمالي نهائي قبل ضبط التعرفة.", color = Color(0xFF9A6A15), fontSize = 12.sp)
                    }
                }
                message?.let { Text(it, color = Color(0xFFB54444), modifier = Modifier.padding(top = 8.dp)) }
                Button(
                    onClick = {
                        message = when {
                            cart.values.sum() == 0 -> "السلة فارغة."
                            name.isBlank() -> "يرجى إدخال الاسم الكامل."
                            !phone.filter { it.isDigit() }.let { it.length in 9..13 } -> "تحقق من رقم الهاتف."
                            wilaya.isBlank() || commune.isBlank() || address.isBlank() -> "أكمل بيانات العنوان."
                            else -> "هذه نسخة واجهة تجريبية: لم يُنشأ طلب ولم تُرسل بيانات إلى خادم."
                        }
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
                ) { Text("مراجعة البيانات") }
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/213561054348"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("استفسر عبر واتساب") }
            }
        }
    }
}

@Composable
private fun FavoritesScreen(favorites: MutableList<Int>, cart: MutableMap<Int, Int>, nav: NavHostController) {
    Column(Modifier.fillMaxSize()) {
        Header(nav, "المفضلة")
        val products = sampleProducts.filter { favorites.contains(it.id) }
        if (products.isEmpty()) EmptyState("لا توجد منتجات محفوظة", "اضغط على القلب لحفظ المنتجات هنا", Icons.Default.FavoriteBorder)
        else ProductList(products, cart, favorites) { nav.navigate("product/$it") }
    }
}

@Composable
private fun SearchScreen(nav: NavHostController, cart: MutableMap<Int, Int>) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("الكل") }
    val categories = listOf("الكل", "هواتف", "صوتيات", "إكسسوارات", "شواحن وكابلات")
    val products = sampleProducts.filter {
        (query.isBlank() || it.name.contains(query, true) || it.category.contains(query, true)) &&
            (category == "الكل" || it.category == category)
    }
    Column(Modifier.fillMaxSize()) {
        Header(nav, "البحث")
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), label = { Text("اسم المنتج") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { cat ->
                FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat, fontSize = 10.sp) })
            }
        }
        LazyColumn { item { ProductList(products, cart, remember { mutableStateListOf() }) { nav.navigate("product/$it") } } }
    }
}

@Composable
private fun SupportScreen() {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Header(rememberNavController(), "مركز الدعم")
        Text("كيف يمكننا مساعدتك؟", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("تواصل مع فريق ZED MOBILE أو راجع الأسئلة الشائعة.", Modifier.padding(horizontal = 18.dp), color = Muted)
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Chat, null, tint = Mint, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("WhatsApp", fontWeight = FontWeight.Bold)
                        Text("0561054348", color = Muted)
                    }
                }
                Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/213561054348"))) }, Modifier.fillMaxWidth()) {
                    Text("تواصل عبر واتساب")
                }
                OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/zargo1044"))) }, Modifier.fillMaxWidth()) {
                    Text("تواصل عبر تيليغرام @zargo1044")
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable {
            // Ticket submission is unavailable until backend is configured.
        }, shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ConfirmationNumber, null, tint = Violet)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("تذكرة دعم", fontWeight = FontWeight.Bold)
                    Text("يتطلب إرسال التذاكر ربط قاعدة البيانات.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Card(Modifier.fillMaxWidth().padding(16.dp).clickable { }, shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.QuestionAnswer, null, tint = Violet)
                Spacer(Modifier.width(12.dp))
                Text("الأسئلة الشائعة", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AccountScreen(nav: NavHostController, dark: MutableState<Boolean>) {
    Column(Modifier.fillMaxSize()) {
        Header(nav, "حسابي")
        Box(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Ink, Violet))).padding(20.dp)) {
            Column {
                Text("مرحباً بك في ZED MOBILE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("أنشئ حساباً لمتابعة طلباتك لاحقاً", color = Lavender, fontSize = 12.sp)
            }
        }
        AccountRow("طلباتي", Icons.Default.ReceiptLong) { nav.navigate("orders") }
        AccountRow("المنتجات المفضلة", Icons.Default.FavoriteBorder) { nav.navigate("favorites") }
        AccountRow("الأسئلة الشائعة", Icons.Default.HelpOutline) { nav.navigate("faq") }
        AccountRow("إعدادات الإدارة (تجريبية)", Icons.Default.AdminPanelSettings) { nav.navigate("admin") }
        Row(Modifier.fillMaxWidth().clickable { dark.value = !dark.value }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DarkMode, null, tint = Violet)
            Spacer(Modifier.width(14.dp))
            Text("تبديل المظهر", Modifier.weight(1f))
            Switch(checked = dark.value, onCheckedChange = { dark.value = it })
        }
        Text("نسخة تطوير 0.1.0 — بيانات تجريبية", Modifier.align(Alignment.CenterHorizontally).padding(20.dp), color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun AccountRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Violet)
        Spacer(Modifier.width(14.dp))
        Text(label, Modifier.weight(1f), fontWeight = FontWeight.Medium)
        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
    }
}

@Composable
private fun OrdersScreen() {
    Column(Modifier.fillMaxSize()) {
        Header(rememberNavController(), "طلباتي")
        EmptyState("لا توجد طلبات بعد", "ستظهر طلباتك هنا بعد ربط التطبيق بالخادم وإتمام طلب حقيقي.", Icons.Default.ReceiptLong)
    }
}

@Composable
private fun AdminScreen() {
    Column(Modifier.fillMaxSize()) {
        Header(rememberNavController(), "ZED MOBILE ADMIN")
        Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0D9))) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, null, tint = Color(0xFF9A6A15))
                Spacer(Modifier.width(10.dp))
                Text("لوحة الإدارة غير مفعّلة للإنتاج. يلزم تسجيل دخول آمن وتحقق صلاحيات من الخادم.", color = Color(0xFF694A1C), fontSize = 13.sp)
            }
        }
        listOf(
            "إدارة المنتجات" to Icons.Default.Inventory2,
            "إدارة الطلبات" to Icons.Default.ReceiptLong,
            "التوصيل والولايات" to Icons.Default.LocalShipping,
            "التذاكر والدعم" to Icons.Default.SupportAgent,
            "العروض والخصومات" to Icons.Default.LocalOffer,
            "الإعدادات" to Icons.Default.Settings
        ).forEach { (label, icon) ->
            AccountRow(label, icon) { }
        }
    }
}

@Composable
private fun FaqScreen() {
    Column(Modifier.fillMaxSize()) {
        Header(rememberNavController(), "الأسئلة الشائعة")
        val faqs = listOf(
            "كيف أطلب منتجاً؟" to "أضف المنتج إلى السلة ثم أدخل معلومات التوصيل. الطلبات الحقيقية تتطلب تفعيل الخادم.",
            "كم تكلفة التوصيل؟" to "تختلف حسب الولاية وطريقة التوصيل، ولا توجد تعرفة مؤكدة مهيأة في نسخة التطوير.",
            "كيف أتتبع طلبي؟" to "ستظهر حالة الطلب بعد ربط نظام الطلبات بالخادم.",
            "كيف أتواصل مع الدعم؟" to "يمكنك التواصل عبر WhatsApp أو Telegram من صفحة الدعم."
        )
        faqs.forEach { (q, a) ->
            var expanded by remember { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { expanded = !expanded }, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(q, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                    }
                    if (expanded) Text(a, Modifier.padding(top = 10.dp), color = Muted, lineHeight = 20.sp)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(
        Modifier.fillMaxWidth().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(86.dp).clip(CircleShape).background(Lavender.copy(alpha = 0.35f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp, lineHeight = 20.sp)
    }
}
