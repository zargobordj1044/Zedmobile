# ZED MOBILE — Android Studio project

Arabic-first Android e-commerce starter for Algeria, built with Kotlin, Jetpack Compose, Material 3 and Navigation Compose.

## Current status

This archive is **Stage 1: UI and local navigation starter**, not a production store yet.
Included: home, search, categories, product detail, local cart, favorites, checkout form validation, support contact links, account, FAQ, orders empty state, and a clearly marked non-production admin screen.

**Not configured / not production-ready:** secure authentication, backend/database, administrator role verification, real product image upload, official wilaya/commune dataset, verified courier pricing, real order creation, tickets backend, payment provider, push notifications, tracking, backup, and signed release. Sample products/prices are placeholders and must be replaced/verified before publishing. No real order is created by this version.

## Requirements

- Android Studio with JDK 17
- Android SDK 35
- Internet access for Gradle dependency resolution
- Compatible Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 are configured

## Open and run

1. Extract this ZIP.
2. Open the `ZED_MOBILE_Android` folder in Android Studio.
3. Allow Gradle sync and install the required Android SDK components if prompted.
4. Run the `app` configuration on an emulator or Android device.

## Build a debug APK

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Or from the project directory where Gradle is installed:
```bash
gradle assembleDebug
```
The output is normally `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK/Gradle installed, so an APK was not built or tested here. Do not treat this project as build-verified.

## Backend recommendation

Use Supabase or Firebase with:
- server-enforced admin roles and row-level/database security rules
- transactional order creation and stock checks
- idempotency key to prevent duplicate orders
- storage policies for product images and ticket attachments
- server-controlled delivery rates and payment status
- audit logs and backups

Never put service-role keys, private API secrets, or admin passwords in the Android app.

## Support links

- WhatsApp: https://wa.me/213561054348
- Telegram: https://t.me/zargo1044

## Suggested next stages

1. Build and verify the UI in Android Studio.
2. Choose Supabase or Firebase and configure secure authentication/database/storage.
3. Import a verified official wilaya/commune dataset and configure courier fees.
4. Implement server-side order creation, support tickets, and admin authorization.
5. Integrate eligible payment provider(s), notifications, and end-to-end tests.
6. Build a signed release APK/AAB after configuration and testing.
