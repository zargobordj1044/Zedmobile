package dz.zedmobile.app

import org.junit.Assert.assertEquals
import org.junit.Test

class CartMathTest {
    @Test fun sampleSubtotalIsCorrect() {
        val items = mapOf(1 to 2, 3 to 1)
        val subtotal = sampleProducts.filter { (items[it.id] ?: 0) > 0 }
            .sumOf { it.price * (items[it.id] ?: 0) }
        assertEquals(152000L, subtotal)
    }
}
